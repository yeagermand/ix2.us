﻿// Copyright (C) 2012 Corel Corp.

var strPlayBtn 	            = "Play";
var strPauseBtn             = "Pause";
var strPrevFrameBtn         = "Previous frame";
var strNextFrameBtn         = "Next frame";
var strMuteBtn 	            = "Mute";
var strUnmuteBtn            = "Unmute";
var strFullScreenBtn        = "Full screen";
var strRestoreFullscreenBtn = "Restore";

var notSupportStringVideo   = "Browser is not supported";
var notSupportStringQTime   = "Please download and install the latest version of QuickTime from www.apple.com/quicktime";