<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>

  <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
  <title>QR Code Readers for iOS, Droid, BB & Win.</title>


  <meta content="QR Code Readers, get your qr code reader for iOS, Android, Blackberry or Windows phone here.  We suggest ignma!" name="description">

<meta name="HandheldFriendly" content="true" />
<meta name="MobileOptimized" content="width" />
<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=2.0, user-scalable=no" /> 
<link rel="stylesheet" type="text/css" href="file:///C|/Users/David/Desktop/qr-codes/style.css">
<link rel="canonical" href="http://ipromotis.com/qr-pics/"/>

  <link href="style.css" rel="stylesheet" type="text/css">
  <style type="text/css">
.auto-style1 {
	text-align: center;
}
.auto-style2 {
	color: #FFFFFF;
}
</style>
  <script type="text/javascript">
<!--
function FP_preloadImgs() {//v1.0
 var d=document,a=arguments; if(!d.FP_imgs) d.FP_imgs=new Array();
 for(var i=0; i<a.length; i++) { d.FP_imgs[i]=new Image; d.FP_imgs[i].src=a[i]; }
}

function FP_swapImg() {//v1.0
 var doc=document,args=arguments,elm,n; doc.$imgSwaps=new Array(); for(n=2; n<args.length;
 n+=2) { elm=FP_getObjectByID(args[n]); if(elm) { doc.$imgSwaps[doc.$imgSwaps.length]=elm;
 elm.$src=elm.src; elm.src=args[n+1]; } }
}

function FP_getObjectByID(id,o) {//v1.0
 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
}
// -->
</script>
  <base target="_self">

</head>
<body marginwidth="0" marginheight="0" topmargin="0" leftmargin="0" style="margin: 0; padding: 0; color: #FFFFFF; background-color: #000000;" onload="FP_preloadImgs(/*url*/'button4.jpg',/*url*/'button5.jpg',/*url*/'button7.jpg',/*url*/'button8.jpg',/*url*/'buttonD.jpg',/*url*/'buttonE.jpg',/*url*/'button10.jpg',/*url*/'button11.jpg',/*url*/'button16.jpg',/*url*/'button17.jpg',/*url*/'button19.jpg',/*url*/'button1A.jpg',/*url*/'button1C.jpg',/*url*/'button1D.jpg',/*url*/'button1F.jpg',/*url*/'button20.jpg')">

<?php 
$sections = 4; 
$l2 = '<a href="http://quickresponseqr.com"><span class="menu">Go To Website</span></a>';
$l3 = '<a href="mailto:promote@promotis.us"><span class="menu">Send An Email</span></a>';
$l4 = '<a href="https://itunes.apple.com/us/app/i-nigma-qr-code-data-matrix/id388923203?mt=8"><span class="menu">iPhone | iPad \ iPod</span></a>';
$l5 = '<a href="https://market.android.com/details?id=com.threegvision.products.inigma.Android"><span class="menu">Android</span></a>';
$l6 = '<a href="http://appworld.blackberry.com/webstore/content/27049?lang=en"><span class="menu">Blackberrry</span></a>';
$l7 = '<a href="http://windowsphone.com/s?appid=828c4e78-1d2b-4fd2-ad22-fde9c553e263"><span class="menu">Windows Phone</span></a>';

$logo = '<img src="images/new-Logo-Standard85.png" alt="Logo for Modern Mobile Marketing PromotIS LC"><br>';
$ctctext = '<a href="tel:4173501473"><span class="menu">Help?  Click to Call Us</span></a>';
?>

<div class="header" style="text-align: center;"><span class="auto-style2">Your Pic Taking Skills Now Open Your World.</span><br>

<?php 
if ($logo != 'images/') {
echo $logo;
}
?>
<p>
<center>PromotIS LC - The Technology to Make It Simple!</center>
<br>
</div>
<div class="auto-style1">
	<a href="http://ipromotis.com">
	<img id="img1" alt="Main Site" fp-style="fp-btn: Glass Rectangle 5; fp-font-size: 16; fp-font-color-hover: #000080; fp-font-color-press: #C0C0C0" fp-title="Main Site" height="32" onmousedown="FP_swapImg(1,0,/*id*/'img1',/*url*/'button5.jpg')" onmouseout="FP_swapImg(0,0,/*id*/'img1',/*url*/'button3.jpg')" onmouseover="FP_swapImg(1,0,/*id*/'img1',/*url*/'button4.jpg')" onmouseup="FP_swapImg(0,0,/*id*/'img1',/*url*/'button4.jpg')" src="button3.jpg" style="border: 0" width="160"></a><br>
	<br>
	<a href="https://itunes.apple.com/us/app/i-nigma-qr-code-data-matrix/id388923203?mt=8">
	<img id="img5" alt="Apple (iPhone)" fp-style="fp-btn: Glass Rectangle 2; fp-font-size: 14" fp-title="Apple (iPhone)" height="30" onmousedown="FP_swapImg(1,0,/*id*/'img5',/*url*/'button17.jpg')" onmouseout="FP_swapImg(0,0,/*id*/'img5',/*url*/'button15.jpg')" onmouseover="FP_swapImg(1,0,/*id*/'img5',/*url*/'button16.jpg')" onmouseup="FP_swapImg(0,0,/*id*/'img5',/*url*/'button16.jpg')" src="button15.jpg" style="border: 0" width="150"></a><br>
	<br>
	<a href="https://market.android.com/details?id=com.threegvision.products.inigma.Android">
	<img id="img6" alt="Android" fp-style="fp-btn: Glass Rectangle 2; fp-font-size: 14" fp-title="Android" height="30" onmousedown="FP_swapImg(1,0,/*id*/'img6',/*url*/'button1A.jpg')" onmouseout="FP_swapImg(0,0,/*id*/'img6',/*url*/'button18.jpg')" onmouseover="FP_swapImg(1,0,/*id*/'img6',/*url*/'button19.jpg')" onmouseup="FP_swapImg(0,0,/*id*/'img6',/*url*/'button19.jpg')" src="button18.jpg" style="border: 0" width="150"></a><br>
	<br><a href="http://appworld.blackberry.com/webstore/content/27049?lang=en">
	<img id="img7" alt="Blackberry" fp-style="fp-btn: Glass Rectangle 2; fp-font-size: 14" fp-title="Blackberry" height="30" onmousedown="FP_swapImg(1,0,/*id*/'img7',/*url*/'button1D.jpg')" onmouseout="FP_swapImg(0,0,/*id*/'img7',/*url*/'button1B.jpg')" onmouseover="FP_swapImg(1,0,/*id*/'img7',/*url*/'button1C.jpg')" onmouseup="FP_swapImg(0,0,/*id*/'img7',/*url*/'button1C.jpg')" src="button1B.jpg" style="border: 0" width="150"></a><br>
	<br>
	<a href="http://windowsphone.com/s?appid=828c4e78-1d2b-4fd2-ad22-fde9c553e263">
	<img id="img8" alt="Windows  Phone" fp-style="fp-btn: Glass Rectangle 2; fp-font-size: 13" fp-title="Windows  Phone" height="30" onmousedown="FP_swapImg(1,0,/*id*/'img8',/*url*/'button20.jpg')" onmouseout="FP_swapImg(0,0,/*id*/'img8',/*url*/'button1E.jpg')" onmouseover="FP_swapImg(1,0,/*id*/'img8',/*url*/'button1F.jpg')" onmouseup="FP_swapImg(0,0,/*id*/'img8',/*url*/'button1F.jpg')" src="button1E.jpg" style="border: 0" width="150"></a><br>
</div>
<div class="footer" style="text-align: center; padding-top: 12;">
	<a href="http://quickresponseqr.com/get-qr">
	<img id="img2" alt="Free QR Code Generator" fp-style="fp-btn: Glass Rectangle 5; fp-font-size: 16; fp-font-color-hover: #000080; fp-font-color-press: #C0C0C0" fp-title="Free QR Code Generator" height="50" onmousedown="FP_swapImg(1,0,/*id*/'img2',/*url*/'button8.jpg')" onmouseout="FP_swapImg(0,0,/*id*/'img2',/*url*/'button6.jpg')" onmouseover="FP_swapImg(1,0,/*id*/'img2',/*url*/'button7.jpg')" onmouseup="FP_swapImg(0,0,/*id*/'img2',/*url*/'button7.jpg')" src="button6.jpg" style="border: 0" width="250"></a>&nbsp;
	<a href="http://ipromotis.com/mag/">
	<img id="img3" alt="Online Help Mag: FREE!" fp-style="fp-btn: Glass Rectangle 5; fp-font-size: 16" fp-title="Online Help Mag: FREE!" height="50" onmousedown="FP_swapImg(1,0,/*id*/'img3',/*url*/'buttonE.jpg')" onmouseout="FP_swapImg(0,0,/*id*/'img3',/*url*/'buttonC.jpg')" onmouseover="FP_swapImg(1,0,/*id*/'img3',/*url*/'buttonD.jpg')" onmouseup="FP_swapImg(0,0,/*id*/'img3',/*url*/'buttonD.jpg')" src="buttonC.jpg" style="border: 0" width="250"></a> |  
	<a href="http://promotis.us/privacy-and-terms">
	<img id="img4" alt="Privacy Policy &amp; TOS" fp-style="fp-btn: Glass Rectangle 5; fp-font-size: 16" fp-title="Privacy Policy &amp; TOS" height="50" onmousedown="FP_swapImg(1,0,/*id*/'img4',/*url*/'button11.jpg')" onmouseout="FP_swapImg(0,0,/*id*/'img4',/*url*/'buttonF.jpg')" onmouseover="FP_swapImg(1,0,/*id*/'img4',/*url*/'button10.jpg')" onmouseup="FP_swapImg(0,0,/*id*/'img4',/*url*/'button10.jpg')" src="buttonF.jpg" style="border: 0" width="250"></a></div>

</body>
</html>
